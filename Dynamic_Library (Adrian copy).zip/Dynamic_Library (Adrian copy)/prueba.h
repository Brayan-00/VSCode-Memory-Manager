//
// Created by heutlett on 7/5/20.
//

#ifndef DYNAMIC_LIBRARY_PRUEBA_H
#define DYNAMIC_LIBRARY_PRUEBA_H


#include "garbageCollector.h"

template <class T>
class prueba {

public:
    garbageCollector * gc = garbageCollector::getInstance();


    void prueba(){



    }



};


#endif //DYNAMIC_LIBRARY_PRUEBA_H
