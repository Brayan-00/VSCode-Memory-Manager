//
// Created by heutlett on 29/4/20.
//
#include "VSPointer.h"
#include "iostream"

garbageCollector * gc = garbageCollector::getInstance();

void deletingTest(){

    VSPointer<int> ptr(new int());
    *ptr = 123;

    VSPointer<int> ptr1(new int());
    ptr1 = ptr;

    VSPointer<int> ptr2(new int());
    ptr2 = ptr1;

    VSPointer<int> ptr3(new int());
    *ptr3 = 5;

    ptr2 = ptr3;



    gc->printElements();
}

int main()
{


    /*
     * Tipos de datos nativos
     *
     * int, bool, char, short, long, long long, float, double, long double
     *
     */

    //TESTING

    //VSPointer<int> ptr(new int());
    //*ptr = 123;

    //int a = &ptr;

    //cout << "El valor de a es :" << a << endl << endl;

    deletingTest();

    //VSPointer<int> ptr9(new int());

    //ptr9 = ptr;

    //*ptr = 666;

    //cout << "El valor de ptr9 es " << &ptr9 << endl << endl;

    //TESTING



    //gc->printElements();

    return 0;
}
